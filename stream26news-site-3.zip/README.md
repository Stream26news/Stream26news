# Stream26 News — Launch Guide

## Decisions locked in
- **Hosting:** free `github.io` subdomain for now, upgrade to a paid `.com` later — no code changes needed when you do.
- **Coverage:** Global News, African News, Nigeria Top News, plus a smaller Opinion & Culture section.
- **Contact email:** stream26news@gmail.com (already wired into `contact.html`).
- **Ad density:** deliberately minimal — one ad slot on the homepage, placed between sections rather than inside article text, so reading stays clean. This is also what Google's own AdSense policies favor: sites with excessive or intrusive ads get flagged, not rewarded.

## What's built
- `index.html` — homepage (red/white theme matching your logo), organized around Global / African / Nigeria sections
- `about.html`, `contact.html`, `privacy-policy.html`, `terms.html` — the four pages AdSense reviewers specifically check for
- `assets/logo-wide.png`, `assets/logo-mark.png` — your uploaded logos, wired into the header, footer, and favicon
- `robots.txt`, `sitemap.xml` — for global search-engine visibility (Google, Bing) — **update the placeholder URL inside both once you know your GitHub username/repo name**
- Open Graph tags in `index.html` so links look right when shared on Facebook/Twitter/WhatsApp — important for a "global reach" goal
- Cookie-consent banner (needed once you run ads)
- One marked ad-slot placeholder on the homepage, ready for your AdSense code

## What I can't do for you, and why
I don't have the ability to click through account signups, verify a real person's identity, or handle payments — hosting providers, domain registrars, and Google AdSense all require *your* email, phone, and (for AdSense) tax/payout details tied to a real bank account. I can't create these on your behalf. What I've done instead: every account below is free, takes about 2 minutes, and I've written the exact clicks so there's no research left for you to do.

---

## Step 1 — Free hosting (no cost, no card required)
**GitHub Pages** is the best fit here — permanent free tier, reliable, and AdSense has no issue with it.

1. Go to github.com → sign up free.
2. Click **New repository**. Name it `stream26-news` (or anything — this name is not public-facing).
3. Upload all the files I gave you (`index.html`, `about.html`, `contact.html`, `privacy-policy.html`, `terms.html`, and the `assets/` folder) — drag-and-drop into the upload screen.
4. Go to **Settings → Pages** → under "Source" choose branch `main`, folder `/root` → Save.
5. Your site is live in ~1 minute at `https://yourusername.github.io/stream26-news/`.

## Step 2 — Domain: staying on github.io for now
You're launching on the free `https://yourusername.github.io/stream26-news/` subdomain — AdSense accepts this fine, and readers anywhere in the world can reach it. When you're ready to upgrade (roughly $8–12/year for a `.com` via Namecheap or Cloudflare Registrar), tell me and I'll update `sitemap.xml`, `robots.txt`, and the Open Graph tags to the new domain in one pass — nothing else about the site needs to change.

**One thing I need from you:** once your GitHub repo is live, send me the exact URL (e.g. `https://gerald123.github.io/stream26-news/`) so I can update the placeholder URLs currently sitting in `robots.txt` and `sitemap.xml`.

## Step 3 — Google AdSense
1. Go to adsense.google.com → sign up with your Google account, enter your site URL.
2. Google gives you a snippet like `<meta name="google-adsense-account" content="ca-pub-XXXXXXXXXX">` — send it to me and I'll add it into `index.html` for you (I left a comment marking exactly where).
3. Submit for review. **Before you submit**, make sure of two things:
   - Replace the placeholder headlines with **real, full articles** — at least 15–20 of them, spread across Global, African, and Nigeria sections. AdSense rejects sites with placeholder or templated text. Tell me when you're ready and I'll draft a batch of genuine articles in each category — I'd suggest starting with 5 per section.
   - Contact email is already set to stream26news@gmail.com — no action needed here.
4. Review typically takes anywhere from a few days to a few weeks. Once approved, Google gives you ad-unit code — send it to me and I'll drop it into the marked `.ad-slot` spot(s).

## Step 4 — Other revenue streams (no capital needed)
- **Affiliate links** (Amazon Associates, or Nigerian equivalents like Jumia's affiliate program) inside relevant articles — free to join.
- **Sponsored posts** once you have consistent traffic — direct outreach to brands, no platform fee.
- **Newsletter** (the signup form is already built) — grow a list, monetize later via sponsorships.
- **Buy Me a Coffee / Ko-fi** button for reader support — free to set up, takes 5 minutes.

## Analytics — Cloudflare Web Analytics (already wired in)
I picked this over Google Analytics for one practical reason: it doesn't use cookies or fingerprinting, so it doesn't trigger cookie-consent requirements the way Google Analytics does — one less compliance thing to manage, and it's already included free with the Cloudflare account you have.

**To activate it (2 minutes, same account you already have):**
1. In the Cloudflare dashboard, go to **Analytics & Logs → Web Analytics**.
2. Click **Add a site**, enter `www.stream26news.workers.dev` (or your future custom domain).
3. Cloudflare gives you a JS snippet with a unique **token**.
4. Send me that token and I'll drop it into the placeholder already sitting in every page (search `YOUR_TOKEN_HERE` — I've pre-inserted the script tag everywhere, it just needs your real token).

Once live, you'll see visits, page views, and a **country-by-country breakdown** of your traffic in that same dashboard.

## Newsletter — Brevo (needs a one-time free signup)
I've built the visual form already (see the "One dispatch a day" section) — it just needs to connect to a real email service.

1. Sign up free at **brevo.com** (formerly Sendinblue) — free tier: unlimited contacts, 300 emails/day.
2. Create a **Contact List** (e.g. "Stream26 Subscribers").
3. Go to **Contacts → Forms → Create a form** → choose "Simple Form" → grab the HTML embed code Brevo generates.
4. Send me that code — I'll transplant its `action` URL and hidden fields into the existing styled form, so it keeps your site's look but actually captures subscribers into Brevo.
5. From Brevo, you can then design and send actual newsletter emails to that list — free, no separate tool needed.

## Moving to GitHub → Cloudflare Pages (auto-deploy, no more ZIP uploads)
This is worth doing now, as you said — it removes the manual re-upload step entirely. Trade-off to know upfront: **this will generate a new URL** (a `pages.dev` address), since it's a different kind of Cloudflare project than the direct-upload one you're on now. Once it's set up, updating the site becomes: edit a file on GitHub → Cloudflare auto-detects the change and redeploys within about a minute, automatically.

**Steps:**
1. Create a free account at **github.com**.
2. Click **New repository** → name it `stream26-news` → keep it **Public** (required for the free Cloudflare integration) → Create.
3. Click **Add file → Upload files** → drag in every file from the ZIP I gave you (`index.html`, `about.html`, `contact.html`, `privacy-policy.html`, `terms.html`, `robots.txt`, `sitemap.xml`, and the `assets` folder) → Commit.
4. In Cloudflare: **Workers & Pages → Create application → Pages → Connect to Git.**
5. Authorize GitHub, select the `stream26-news` repo.
6. Build settings: **Framework preset: None**, **Build command: (leave blank)**, **Build output directory: /** (just a single forward slash — this tells Cloudflare the files are already sitting at the root, nothing to build).
7. Click **Save and Deploy**.

You'll get a new address like `stream26-news.pages.dev` (or similar — Cloudflare will show you the exact one). Send it to me and I'll do the same sitemap/robots.txt/social-tag update I did last time, plus re-add the analytics token if you've already gotten it.

**From then on, adding or editing an article means:** open the file on GitHub (in your browser, tap the pencil/edit icon on any file), make the change, tap **Commit changes** — Cloudflare rebuilds automatically. No downloads, no ZIP files, no re-uploading.

## Global reach — what's already in place, and what helps next
- **Open Graph tags** are in `index.html` so links preview correctly on social media worldwide.
- **`sitemap.xml` + `robots.txt`** help Google and Bing index the site (update URLs once your repo is live — see Step 2).
- Once you have ~15–20 real articles, submitting your sitemap to **Google Search Console** (free) is the single biggest lever for actual global search visibility — I can walk you through that once content is in place.
- Consider adding a couple of articles specifically framed for a global audience reading about Africa/Nigeria (context-setting, not just insider shorthand) — this widens who finds and shares your content.
